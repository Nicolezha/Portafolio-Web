import { Card } from "@/components/ui/card";
import { Briefcase, Calendar } from "lucide-react";

const experiences = [
  {
    company: "Ericsson",
    position: "Ingeniera Informática",
    location: "Madrid",
    period: "01/2017 - Actual",
    current: true,
    responsibilities: [
      "Coordinación de un equipo de más de 10 personas",
      "Formación a técnicos de la compañía sobre el funcionamiento de sistemas",
      "Realización de cálculos de datos de prueba para la mejora del rendimiento de los sistemas",
    ],
  },
  {
    company: "BT",
    position: "Ingeniera Informática",
    location: "Madrid",
    period: "10/2012 - 12/2016",
    current: false,
    responsibilities: [
      "Realización de estimaciones del tiempo necesario para la ejecución de proyectos",
      "Mejora de procesos mediante soluciones informáticas creadas en Python",
      "Asesoramiento técnico personalizado sobre transformación digital y arquitectura de soluciones",
    ],
  },
  {
    company: "Indra",
    position: "Técnica Informática",
    location: "Madrid",
    period: "10/2010 - 03/2012",
    current: false,
    responsibilities: [
      "Mantenimiento y reparación del hardware, y aplicación de medidas de prevención de fallos",
      "Asesoramiento a usuarios para la configuración y el uso de computadoras",
      "Aplicación de procedimientos de operación de sistemas de grandes centros de datos",
    ],
  },
];

export default function ExperienceSection() {
  return (
    <section id="experience" className="py-20 bg-muted/30">
      <div className="container">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12 animate-in fade-in slide-in-from-bottom duration-500">
            <h2 className="text-4xl font-bold mb-4 text-foreground">
              Experiencia Laboral
            </h2>
            <div className="w-20 h-1 bg-primary mx-auto rounded-full"></div>
          </div>

          <div className="space-y-6">
            {experiences.map((exp, index) => (
              <Card
                key={index}
                className="p-6 hover:shadow-lg transition-all duration-300 hover:-translate-y-1 animate-in fade-in slide-in-from-left"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="flex flex-col md:flex-row md:items-start md:justify-between mb-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <Briefcase className="h-5 w-5 text-primary" />
                      <h3 className="text-2xl font-semibold text-foreground">
                        {exp.position}
                      </h3>
                      {exp.current && (
                        <span className="px-3 py-1 text-xs font-medium bg-primary/10 text-primary rounded-full">
                          Actual
                        </span>
                      )}
                    </div>
                    <p className="text-lg font-medium text-primary mb-1">
                      {exp.company}
                    </p>
                    <p className="text-sm text-muted-foreground">{exp.location}</p>
                  </div>
                  <div className="flex items-center gap-2 text-muted-foreground mt-2 md:mt-0">
                    <Calendar className="h-4 w-4" />
                    <span className="text-sm font-medium">{exp.period}</span>
                  </div>
                </div>

                <ul className="space-y-2 ml-7">
                  {exp.responsibilities.map((resp, idx) => (
                    <li
                      key={idx}
                      className="text-foreground/80 leading-relaxed flex items-start"
                    >
                      <span className="inline-block w-1.5 h-1.5 rounded-full bg-primary mt-2 mr-3 flex-shrink-0"></span>
                      <span>{resp}</span>
                    </li>
                  ))}
                </ul>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
