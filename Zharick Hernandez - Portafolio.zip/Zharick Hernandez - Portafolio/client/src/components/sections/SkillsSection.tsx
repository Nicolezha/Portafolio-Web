import { Card } from "@/components/ui/card";
import { Code, Wrench, Globe } from "lucide-react";

const skillsData = {
  languages: {
    title: "Lenguajes de Programación",
    icon: Code,
    items: ["Java", "Python", "C/C++", "PHP"],
  },
  technical: {
    title: "Aptitudes Técnicas",
    icon: Wrench,
    items: [
      "Dirección de equipos",
      "Resolución de incidencias",
      "Capacidad de análisis",
      "Diagnóstico de fallos",
      "Instalación de equipos",
      "Ciberseguridad",
    ],
  },
  languages_spoken: {
    title: "Idiomas",
    icon: Globe,
    items: ["Español (Nativo)", "Inglés (Avanzado - C1)"],
  },
};

export default function SkillsSection() {
  return (
    <section id="skills" className="py-20 bg-muted/30">
      <div className="container">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-12 animate-in fade-in slide-in-from-bottom duration-500">
            <h2 className="text-4xl font-bold mb-4 text-foreground">
              Habilidades
            </h2>
            <div className="w-20 h-1 bg-primary mx-auto rounded-full"></div>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {Object.entries(skillsData).map(([key, category], index) => (
              <Card
                key={key}
                className="p-6 hover:shadow-lg transition-all duration-300 hover:-translate-y-1 animate-in fade-in slide-in-from-bottom"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
                    <category.icon className="h-6 w-6 text-primary" />
                  </div>
                  <h3 className="text-xl font-semibold text-foreground">
                    {category.title}
                  </h3>
                </div>
                <ul className="space-y-2">
                  {category.items.map((item, idx) => (
                    <li
                      key={idx}
                      className="flex items-center text-foreground/80"
                    >
                      <span className="inline-block w-1.5 h-1.5 rounded-full bg-primary mr-3 flex-shrink-0"></span>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
