import { Button } from "@/components/ui/button";
import { Github, Linkedin, Mail, ChevronDown } from "lucide-react";

export default function HeroSection() {
  const scrollToContact = () => {
    const element = document.querySelector("#contact");
    if (element) {
      element.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  return (
    <section
      id="home"
      className="min-h-screen flex items-center justify-center pt-16 bg-gradient-to-br from-primary/5 via-background to-accent/5"
    >
      <div className="container">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          {/* Text Content */}
          <div className="space-y-6 animate-in fade-in slide-in-from-left duration-700">
            <div className="space-y-2">
              <p className="text-primary font-medium text-lg">Hola, soy</p>
              <h1 className="text-5xl md:text-6xl font-bold text-foreground leading-tight">
                Nicole Hernandez
              </h1>
              <h2 className="text-2xl md:text-3xl text-muted-foreground font-medium">
                Ingeniera de Sistemas
              </h2>
            </div>

            <p className="text-lg text-foreground/80 leading-relaxed max-w-xl">
              Más de 12 años de experiencia proporcionando soporte excepcional y
              soluciones técnicas innovadoras. Especializada en gestión de equipos,
              transformación digital y optimización de sistemas.
            </p>

            <div className="flex flex-wrap gap-4">
              <Button
                size="lg"
                onClick={scrollToContact}
                className="group"
              >
                Contáctame
                <Mail className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
              </Button>
              <Button
                variant="outline"
                size="lg"
                asChild
              >
                <a
                  href="https://github.com/Nicolezha"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="group"
                >
                  <Github className="mr-2 h-4 w-4" />
                  GitHub
                </a>
              </Button>
              <Button
                variant="outline"
                size="lg"
                asChild
              >
                <a
                  href="https://www.linkedin.com/in/zharick-nicole-hernandez-arevalo-1b601035a/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="group"
                >
                  <Linkedin className="mr-2 h-4 w-4" />
                  LinkedIn
                </a>
              </Button>
            </div>
          </div>

          {/* Photo */}
          <div className="flex justify-center animate-in fade-in slide-in-from-right duration-700 delay-200">
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-br from-primary to-accent rounded-full blur-2xl opacity-20 animate-pulse"></div>
              <img
                src="https://media.licdn.com/dms/image/v2/D5603AQHpMR8q9-EsjA/profile-displayphoto-crop_800_800/B56ZiPzhzYH0AI-/0/1754759308038?e=1765411200&v=beta&t=VbmFkaqtldC6MRGu_QSNY22ycI_183yqRwqz0UxnZUM"
                alt="Nicole Hernandez"
                className="relative rounded-full w-72 h-72 md:w-96 md:h-96 object-cover border-4 border-primary/20 shadow-2xl"
              />
            </div>
          </div>
        </div>

        {/* Scroll Indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
          <ChevronDown className="h-8 w-8 text-primary/60" />
        </div>
      </div>
    </section>
  );
}
