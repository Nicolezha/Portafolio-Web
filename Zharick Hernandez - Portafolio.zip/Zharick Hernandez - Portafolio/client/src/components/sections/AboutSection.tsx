import { Card } from "@/components/ui/card";
import { Users, Target, Award } from "lucide-react";

export default function AboutSection() {
  const highlights = [
    {
      icon: Users,
      title: "12+ Años",
      description: "De experiencia en tecnología",
    },
    {
      icon: Target,
      title: "Gestión de Equipos",
      description: "Liderazgo de equipos técnicos",
    },
    {
      icon: Award,
      title: "Experta",
      description: "En soporte y soluciones IT",
    },
  ];

  return (
    <section id="about" className="py-20 bg-background">
      <div className="container">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12 animate-in fade-in slide-in-from-bottom duration-500">
            <h2 className="text-4xl font-bold mb-4 text-foreground">
              Sobre Mí
            </h2>
            <div className="w-20 h-1 bg-primary mx-auto rounded-full"></div>
          </div>

          <div className="space-y-8">
            <Card className="p-8 animate-in fade-in slide-in-from-bottom duration-500 delay-100">
              <h3 className="text-2xl font-semibold mb-4 text-primary">
                Perfil Profesional
              </h3>
              <p className="text-lg text-foreground/80 leading-relaxed">
                Ingeniera informática con excelentes habilidades y conocimientos con más
                de 12 años de experiencia proporcionando un soporte excepcional a los
                usuarios de todos los niveles. Experta en cuestiones de soporte y con
                buena reputación como técnico capacitado para trabajar en equipo y
                encontrar soluciones.
              </p>
            </Card>

            <div className="grid md:grid-cols-3 gap-6">
              {highlights.map((item, index) => (
                <Card
                  key={index}
                  className="p-6 text-center hover:shadow-lg transition-all duration-300 hover:-translate-y-1 animate-in fade-in slide-in-from-bottom"
                  style={{ animationDelay: `${(index + 2) * 100}ms` }}
                >
                  <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 mb-4">
                    <item.icon className="h-8 w-8 text-primary" />
                  </div>
                  <h4 className="text-xl font-semibold mb-2 text-foreground">
                    {item.title}
                  </h4>
                  <p className="text-muted-foreground">{item.description}</p>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
