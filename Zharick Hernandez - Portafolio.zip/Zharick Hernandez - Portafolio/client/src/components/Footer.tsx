import { Github, Linkedin, Mail } from "lucide-react";

export default function Footer() {
  const currentYear = new Date().getFullYear();

  const socialLinks = [
    {
      icon: Github,
      href: "https://github.com/Nicolezha",
      label: "GitHub",
    },
    {
      icon: Linkedin,
      href: "https://www.linkedin.com/in/zharick-nicole-hernandez-arevalo-1b601035a/",
      label: "LinkedIn",
    },
    {
      icon: Mail,
      href: "mailto:macabrera@gmail.com",
      label: "Email",
    },
  ];

  return (
    <footer className="bg-muted/30 border-t border-border">
      <div className="container py-8">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="text-center md:text-left">
            <p className="text-foreground font-semibold">Nicole Hernandez</p>
            <p className="text-sm text-muted-foreground">
              Ingeniera de Sistemas
            </p>
          </div>

          <div className="flex items-center gap-4">
            {socialLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                target="_blank"
                rel="noopener noreferrer"
                aria-label={link.label}
                className="w-10 h-10 rounded-full bg-primary/10 hover:bg-primary hover:text-primary-foreground text-primary flex items-center justify-center transition-all duration-300 hover:scale-110"
              >
                <link.icon className="h-5 w-5" />
              </a>
            ))}
          </div>

          <div className="text-center md:text-right">
            <p className="text-sm text-muted-foreground">
              © {currentYear} Nicole Hernandez. Todos los derechos reservados.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}
