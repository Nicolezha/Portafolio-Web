# Portfolio María Álvarez Cabrera - Ingeniera Informática

Portafolio web profesional desarrollado con React 19, Tailwind CSS 4 y TypeScript. Diseño moderno con paleta de colores violeta/púrpura y cyan, totalmente responsive y con modo claro/oscuro.

## 🚀 Características

- ✅ Diseño moderno y profesional
- ✅ Totalmente responsive (mobile-first)
- ✅ Modo claro/oscuro con toggle
- ✅ Animaciones sutiles con CSS
- ✅ Navegación con smooth scroll
- ✅ Formulario de contacto integrado con Formspree
- ✅ SEO optimizado con meta tags
- ✅ Accesibilidad (ARIA, contraste, navegación por teclado)
- ✅ Tipografía profesional (Inter + Poppins)

## 📁 Estructura del Proyecto

```
portfolio-maria-alvarez/
├── client/
│   ├── public/
│   │   └── maria-alvarez.png          # Tu foto de perfil
│   ├── src/
│   │   ├── components/
│   │   │   ├── sections/              # Secciones del portafolio
│   │   │   │   ├── HeroSection.tsx    # Sección principal con foto
│   │   │   │   ├── AboutSection.tsx   # Sobre mí
│   │   │   │   ├── ExperienceSection.tsx  # Experiencia laboral
│   │   │   │   ├── EducationSection.tsx   # Formación académica
│   │   │   │   ├── SkillsSection.tsx      # Habilidades
│   │   │   │   └── ContactSection.tsx     # Formulario de contacto
│   │   │   ├── Navigation.tsx         # Barra de navegación
│   │   │   └── Footer.tsx             # Pie de página
│   │   ├── pages/
│   │   │   └── Home.tsx               # Página principal
│   │   ├── index.css                  # Estilos globales y tema
│   │   └── App.tsx                    # Configuración de la app
│   └── index.html                     # HTML principal
├── README.md                          # Este archivo
└── todo.md                            # Lista de tareas completadas
```

## 🎨 Personalización

### Cambiar Colores

Los colores se definen en `client/src/index.css` usando variables CSS en formato OKLCH:

```css
:root {
  --primary: oklch(0.55 0.25 290);     /* Violeta principal */
  --accent: oklch(0.75 0.18 195);      /* Cyan acento */
  /* ... más variables */
}
```

### Cambiar Contenido

Cada sección del portafolio está en su propio archivo dentro de `client/src/components/sections/`. Para modificar el contenido:

1. **Información personal**: Edita `HeroSection.tsx` y `AboutSection.tsx`
2. **Experiencia laboral**: Edita el array `experiences` en `ExperienceSection.tsx`
3. **Educación**: Edita el array `education` en `EducationSection.tsx`
4. **Habilidades**: Edita el objeto `skillsData` en `SkillsSection.tsx`
5. **Contacto**: Edita `contactInfo` en `ContactSection.tsx`

### Cambiar Foto

1. Reemplaza el archivo `client/public/maria-alvarez.png` con tu nueva foto
2. Mantén el mismo nombre o actualiza la referencia en `HeroSection.tsx` (línea con `src="/maria-alvarez.png"`)
3. Recomendación: Usa una imagen cuadrada de al menos 800x800px para mejor calidad

### Actualizar Favicon

El favicon se gestiona desde el panel de administración (Management UI):
1. Abre el proyecto en el navegador
2. Ve a **Settings** → **General**
3. Sube tu nuevo favicon en la sección correspondiente

## 📧 Configurar Formulario de Contacto (Formspree)

El formulario de contacto está preparado para usar Formspree. Para activarlo:

1. Ve a [https://formspree.io](https://formspree.io) y crea una cuenta gratuita
2. Crea un nuevo formulario y copia tu Form ID
3. Edita `client/src/components/sections/ContactSection.tsx`
4. En la línea 73, reemplaza `YOUR_FORM_ID` con tu ID real:

```typescript
const response = await fetch("https://formspree.io/f/TU_FORM_ID_AQUI", {
```

5. Guarda el archivo y el formulario estará funcional

**Alternativa sin Formspree**: Si prefieres no usar Formspree, el formulario ya incluye validación en cliente. Los mensajes se pueden enviar por mailto (edita la función `handleSubmit` para usar `mailto:`).

## 🛠️ Desarrollo Local

### Requisitos Previos

- Node.js 18+ instalado
- pnpm (gestor de paquetes)

### Instalación

```bash
# Instalar dependencias
pnpm install

# Iniciar servidor de desarrollo
pnpm dev

# El sitio estará disponible en http://localhost:3000
```

### Comandos Disponibles

```bash
pnpm dev          # Inicia el servidor de desarrollo
pnpm build        # Construye la versión de producción
pnpm preview      # Previsualiza la build de producción
pnpm lint         # Ejecuta el linter
```

## 🌐 Despliegue

### Opción 1: Publicar desde Management UI (Recomendado)

1. Guarda un checkpoint desde el chat
2. Haz clic en el botón **Publish** en el Management UI
3. Tu sitio estará disponible en `https://tu-dominio.manus.space`

### Opción 2: Desplegar en otros servicios

El proyecto se puede desplegar en cualquier servicio de hosting estático:

- **Vercel**: Conecta tu repositorio y despliega automáticamente
- **Netlify**: Arrastra la carpeta `dist` después de ejecutar `pnpm build`
- **GitHub Pages**: Configura el workflow de GitHub Actions
- **Cloudflare Pages**: Conecta tu repositorio

Configuración de build:
- Build command: `pnpm build`
- Output directory: `dist`
- Node version: 18+

## 📱 Responsive Design

El portafolio está optimizado para todos los dispositivos:

- **Móvil**: Menú hamburguesa, layout vertical
- **Tablet**: Grid adaptativo, navegación completa
- **Desktop**: Layout completo con animaciones

## ♿ Accesibilidad

- Navegación por teclado completa
- Etiquetas ARIA apropiadas
- Contraste de colores WCAG AA
- Textos alternativos en imágenes
- Focus visible en elementos interactivos

## 🔍 SEO

El proyecto incluye:
- Meta tags básicos configurados
- Títulos semánticos (h1, h2, h3)
- Estructura HTML semántica
- Open Graph tags (puedes añadir más en `client/index.html`)

Para mejorar el SEO:
1. Edita `client/index.html` y añade meta description
2. Añade Open Graph tags para redes sociales
3. Considera añadir un sitemap.xml

## 📝 Notas Importantes

- **Privacidad**: Revisa que la información de contacto sea la correcta antes de publicar
- **Imágenes**: Todas las imágenes deben estar optimizadas para web (formato WebP recomendado)
- **Formspree**: El plan gratuito tiene límite de 50 envíos/mes
- **Favicon**: Actualízalo desde Settings → General en el Management UI

## 🆘 Soporte

Si tienes problemas o preguntas:
- Revisa la documentación de React: [https://react.dev](https://react.dev)
- Documentación de Tailwind CSS: [https://tailwindcss.com](https://tailwindcss.com)
- Soporte de Formspree: [https://help.formspree.io](https://help.formspree.io)

## 📄 Licencia

Este proyecto es de uso personal. Todos los derechos reservados a María Álvarez Cabrera.

---

**Desarrollado con ❤️ usando React, Tailwind CSS y TypeScript**
