# Portfolio María Álvarez - TODO

## Configuración Base
- [x] Configurar tema de colores moderno violeta/púrpura con cyan
- [x] Configurar tipografía profesional con Google Fonts
- [x] Configurar modo oscuro/claro con toggle
- [x] Actualizar logo y constantes del proyecto

## Estructura y Navegación
- [x] Crear componente de navegación principal con smooth scroll
- [x] Implementar menú responsive para móviles
- [x] Configurar rutas para todas las secciones

## Páginas y Secciones
- [x] Sección Home/Hero con foto y presentación
- [x] Sección Sobre Mí con resumen profesional
- [x] Sección Experiencia Laboral (Ericsson, BT, Indra)
- [x] Sección Educación (Máster UNIR, Ingeniería UPM)
- [x] Sección Habilidades (lenguajes y aptitudes)
- [x] Sección Contacto con formulario

## Funcionalidades
- [x] Integrar formulario de contacto con Formspree
- [x] Implementar validación de formulario en cliente
- [x] Agregar animaciones CSS sutiles
- [x] Implementar smooth scroll entre secciones
- [x] Agregar enlaces a GitHub y LinkedIn

## Optimización y Buenas Prácticas
- [x] Implementar HTML semántico
- [x] Agregar meta tags para SEO
- [x] Agregar meta tags Open Graph
- [x] Asegurar accesibilidad (ARIA, alt, contraste)
- [x] Optimizar imágenes y assets
- [x] Asegurar diseño responsive mobile-first

## Entrega Final
- [x] Copiar foto de María a assets
- [x] Crear README.md con instrucciones
- [x] Verificar funcionamiento en navegador
- [x] Empaquetar todo en ZIP para descarga
